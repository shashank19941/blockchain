# Academic-Grades-System-using-Blockchain
Academic-Grades-System-using-Blockchain designed by the developer to demonstrate a simple implementation of Blockchain technology

techniques used:
1. Hash algorithm
2. Encryption algorithm 
3. Digital signature
4. Object Oriented Programming
5. Text files 

For more inforomation: ak_aldhafer@hotmail.com

https://www.linkedin.com/in/abdulmalek-aldhafer-206485173/

https://github.com/akaldhafer 
