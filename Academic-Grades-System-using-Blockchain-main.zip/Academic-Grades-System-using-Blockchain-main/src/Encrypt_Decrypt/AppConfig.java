package Encrypt_Decrypt;

public class AppConfig {

    //algorithm
    public static final String ALGORITHM = "RSA";   
    //location of keypair
    public static final String PUBLICKEY_FILE = "KeyPair/Publickey";
    public static final String PRIVATEKEY_FILE = "KeyPair/Privatekey";
    
}
